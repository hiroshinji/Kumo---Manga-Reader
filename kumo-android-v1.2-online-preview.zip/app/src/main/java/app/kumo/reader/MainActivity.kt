package app.kumo.reader

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var fullscreen = false
    private var chooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingSharedUrl: String? = null
    private var pageReady = false

    // Resultado do seletor de arquivos nativo (Storage Access Framework).
    private val chooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val cb = chooserCallback
            chooserCallback = null
            cb?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            )
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Desenhamos por baixo das barras do sistema e aplicamos os insets manualmente,
        // para o comportamento ser igual do Android 8 ao 15 e permitir tela cheia de verdade.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = false

        val bg = Color.parseColor("#0d0d11")
        val root = FrameLayout(this).apply { setBackgroundColor(bg) }

        web = WebView(this).apply {
            setBackgroundColor(bg)
            overScrollMode = View.OVER_SCROLL_NEVER
            isLongClickable = false
            setOnLongClickListener { true }
            isHapticFeedbackEnabled = false
        }
        root.addView(
            web,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }

        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true       // localStorage + IndexedDB (biblioteca salva)
            allowFileAccess = false        // os assets são servidos por https://appassets...
            allowContentAccess = true
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            textZoom = 100
        }

        // Serve a pasta assets/ por https://appassets.androidplatform.net/assets/...
        // (necessário para Web Worker do PDF.js, IndexedDB e blob: funcionarem direito).
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                pageReady = true
                pendingSharedUrl?.let { shared ->
                    pendingSharedUrl = null
                    deliverSharedUrl(shared)
                }
            }
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean = request.url.host != WebViewAssetLoader.DEFAULT_DOMAIN
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (filePathCallback == null) return false
                chooserCallback?.onReceiveValue(null)
                chooserCallback = filePathCallback

                val accept = fileChooserParams?.acceptTypes?.joinToString(",")?.lowercase().orEmpty()
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    // "image/*" abriria o Google Fotos; "*/*" abre o seletor de documentos
                    // (Arquivos). O HTML valida o que foi escolhido (imagens, CBZ/ZIP, PDF).
                    val onlyPdf = accept.contains("pdf") && !accept.contains("image/") && !accept.contains("zip")
                    type = if (onlyPdf) "application/pdf" else "*/*"
                    if (fileChooserParams?.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) {
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }
                }
                return try {
                    chooserLauncher.launch(intent)
                    true
                } catch (e: Exception) {
                    chooserCallback = null
                    filePathCallback.onReceiveValue(null)
                    false
                }
            }
        }

        web.addJavascriptInterface(Bridge(), "KumoNative")

        // Botão/gesto voltar: o HTML decide (leitor -> biblioteca -> sair).
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.kumoBack?window.kumoBack():false)") { r ->
                    if (r != "true") finish()
                }
            }
        })

        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val raw = when (intent.action) {
            Intent.ACTION_SEND -> intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
            Intent.ACTION_VIEW -> intent.dataString
            else -> null
        }?.trim()?.let { text ->
            // Aceita URL simples ou texto contendo uma URL HTTPS/HTTP compartilhada.
            Regex("""https?://[^\s<>"']+""", RegexOption.IGNORE_CASE).find(text)?.value
        } ?: return
        val uri = safeWebUri(raw) ?: return
        pendingSharedUrl = uri.toString()
        if (::web.isInitialized && pageReady) {
            deliverSharedUrl(uri.toString())
            pendingSharedUrl = null
        }
    }

    private fun deliverSharedUrl(raw: String) {
        val uri = safeWebUri(raw) ?: return
        web.evaluateJavascript("window.kumoReceiveSharedUrl&&window.kumoReceiveSharedUrl(${org.json.JSONObject.quote(uri.toString())})", null)
    }

    private fun safeWebUri(raw: String): Uri? = try {
        val uri = Uri.parse(raw)
        if ((uri.scheme == "https" || uri.scheme == "http") && !uri.host.isNullOrBlank() && uri.userInfo == null) uri else null
    } catch (_: Exception) { null }

    // A área de catálogo só abre domínios oficiais previamente permitidos.
    private fun safeOfficialUri(raw: String): Uri? {
        val uri = safeWebUri(raw) ?: return null
        if (uri.scheme != "https") return null
        val host = uri.host!!.lowercase()
        val allowed = setOf("mangaplus.shueisha.co.jp", "www.webtoons.com", "webtoons.com")
        return uri.takeIf { host in allowed }
    }

    private fun applyFullscreen(on: Boolean) {
        fullscreen = on
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (on) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
        web.evaluateJavascript("window.kumoFsChanged&&window.kumoFsChanged($on)", null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun setFullscreen(on: Boolean) {
            runOnUiThread { applyFullscreen(on) }
        }

        @JavascriptInterface
        fun isFullscreen(): Boolean = fullscreen

        @JavascriptInterface
        fun openSharedUrl(raw: String) {
            runOnUiThread {
                val uri = safeWebUri(raw) ?: return@runOnUiThread
                try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                catch (_: Exception) { web.evaluateJavascript("window.kumoOnlineError&&window.kumoOnlineError()", null) }
            }
        }

        @JavascriptInterface
        fun openOfficialUrl(raw: String) {
            runOnUiThread {
                val uri = safeOfficialUri(raw) ?: return@runOnUiThread
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (_: Exception) {
                    web.evaluateJavascript("window.kumoOnlineError&&window.kumoOnlineError()", null)
                }
            }
        }

        @JavascriptInterface
        fun setKeepAwake(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && fullscreen) {
            WindowCompat.getInsetsController(window, window.decorView)
                .hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onPause() {
        // Garante que a página atual seja gravada antes de ir para segundo plano.
        web.evaluateJavascript("window.kumoSave&&window.kumoSave()", null)
        web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }
}
