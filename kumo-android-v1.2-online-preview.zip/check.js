(function(){var sp=document.getElementById('splash'),rm=window.matchMedia&&matchMedia('(prefers-reduced-motion:reduce)').matches;window.kumoHideSplash=function(){if(!sp||sp.dataset.hidden)return;sp.dataset.hidden='1';sp.classList.add('out');setTimeout(function(){sp.remove()},320)};window.addEventListener('load',function(){setTimeout(window.kumoHideSplash,rm?350:1500)},{once:true});setTimeout(window.kumoHideSplash,4500)})()



(()=>{'use strict';const $=id=>document.getElementById(id);const S={books:[],book:null,page:0,mode:'paged',brightness:100,theme:'dark',transition:'slide',rtl:true,bookmarks:new Set(),wake:null,gesture:null,zoom:1,pdfRender:0,pdfDoc:null,pointers:new Map(),drag:null,basePageWidth:0,basePageHeight:0};
const screens=['home','settings','readerScreen'];function toast(s){let r=$('toastRoot');r.innerHTML='';let d=document.createElement('div');d.className='toast';d.textContent=s;r.append(d);clearTimeout(toast.t);toast.t=setTimeout(()=>{d.classList.add('out');setTimeout(()=>d.remove(),300)},2500)}
const ORDER={home:0,settings:1,readerScreen:2};
const reduced=()=>window.matchMedia&&matchMedia('(prefers-reduced-motion:reduce)').matches;
function navAnim(prev,id){
 const pe=$(prev),ne=$(id);if(reduced())return;
 const fwd=ORDER[id]>ORDER[prev],toR=id==='readerScreen',fromR=prev==='readerScreen';
 ne.classList.remove('leaving');ne.getAnimations().forEach(a=>a.cancel());
 pe.classList.add('leaving');
 const out=pe.animate(toR?[{opacity:1,transform:'scale(1)'},{opacity:0,transform:'scale(.95)'}]:fromR?[{opacity:1,transform:'scale(1)'},{opacity:0,transform:'scale(1.05)'}]:[{opacity:1,transform:'none'},{opacity:0,transform:'translateX('+(fwd?-26:26)+'px) scale(.985)'}],{duration:260,easing:'cubic-bezier(.4,0,.2,1)',fill:'forwards'});
 out.onfinish=()=>{if(!pe.classList.contains('active'))pe.classList.remove('leaving');out.cancel()};
 ne.animate(toR?[{opacity:0,transform:'scale(1.06)'},{opacity:1,transform:'scale(1)'}]:fromR?[{opacity:0,transform:'scale(.95)'},{opacity:1,transform:'scale(1)'}]:[{opacity:0,transform:'translateX('+(fwd?30:-30)+'px) scale(.985)'},{opacity:1,transform:'none'}],{duration:380,easing:'cubic-bezier(.2,.9,.25,1)'})}
function show(id){
 if(id==='settings'&&$('readerScreen').classList.contains('active'))S.settingsReturn='readerScreen';else if(id==='settings'&&$('home').classList.contains('active'))S.settingsReturn='home';
 const prev=screens.find(x=>$(x).classList.contains('active'));
 if(prev==='home'&&id!=='home')S.homeScroll=$('home').scrollTop;
 screens.forEach(x=>$(x).classList.toggle('active',x===id));
 $('top').classList.toggle('hidden',id==='readerScreen');$('nav').classList.toggle('hidden',id==='readerScreen');
 document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('active',b.dataset.target===id));
 $('nav').style.setProperty('--idx',id==='settings'?1:0);
 if(id==='settings')$('backHome').textContent=S.settingsReturn==='readerScreen'?'Voltar ao leitor':'Voltar à biblioteca';
 if(id==='home'&&S.libDirty)renderLibrary(true);
 if(prev&&prev!==id)navAnim(prev,id);
 if(id==='home'&&prev!==id)requestAnimationFrame(()=>{$('home').scrollTop=S.homeScroll||0})}
function sort(a,b){return a.name.localeCompare(b.name,undefined,{numeric:true,sensitivity:'base'})}
let dbp=null;
function db(){return dbp||(dbp=new Promise((ok,fail)=>{const r=indexedDB.open('kumo',1);r.onupgradeneeded=()=>{const d=r.result;d.createObjectStore('books',{keyPath:'id'});d.createObjectStore('pages');d.createObjectStore('pdfs')};r.onsuccess=()=>ok(r.result);r.onerror=()=>{dbp=null;fail(r.error)}}))}
function idb(stores,mode,fn){return db().then(d=>new Promise((ok,fail)=>{const t=d.transaction(stores,mode);let r;try{r=fn(t)}catch(e){try{t.abort()}catch{}fail(e);return}t.oncomplete=()=>ok(r&&typeof r==='object'&&'result' in r?r.result:r);t.onerror=()=>fail(t.error);t.onabort=()=>fail(t.error||new Error('Transação cancelada'))}))}

// Backup ZIP local: inclui metadados, páginas binárias, PDFs e preferências Kumo.
async function kumoReadStore(store){
 const d=await db(); return new Promise((resolve,reject)=>{
  const tx=d.transaction([store],'readonly'), os=tx.objectStore(store), rq=os.getAll(), kq=os.getAllKeys();
  tx.oncomplete=()=>resolve(rq.result.map((value,i)=>({key:kq.result[i],value})));
  tx.onerror=()=>reject(tx.error);
 });
}
async function kumoBackupExport(){
 const btn=$('backupExport');btn.disabled=true;
 try{
  if(!window.JSZip)throw new Error('Biblioteca ZIP indisponível');
  flushMeta();
  const zip=new JSZip(), stores={};
  for(const name of ['books','pages','pdfs']){
   const rows=await kumoReadStore(name);stores[name]=[];
   for(let i=0;i<rows.length;i++){
    const row=rows[i];
    if(name==='books')stores[name].push({key:row.key,value:row.value});
    else {const path='data/'+name+'/'+i+'.bin';zip.file(path,row.value);stores[name].push({key:row.key,path,blob:true,type:row.value?.type||'application/octet-stream'});}
   }
  }
  const local={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith('kumo:'))local[k]=localStorage.getItem(k)}
  zip.file('kumo-backup.json',JSON.stringify({format:'kumo-backup',version:1,createdAt:new Date().toISOString(),stores,localStorage:local}));
  const blob=await zip.generateAsync({type:'blob',compression:'DEFLATE',compressionOptions:{level:3}});
  const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='Kumo-Backup-'+new Date().toISOString().slice(0,10)+'.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);
  toast('Backup exportado. Guarde o ZIP em local seguro.',3500);
 }catch(e){console.error(e);toast('Não foi possível exportar: '+(e.message||'erro'),4500)}finally{btn.disabled=false}
}
async function kumoBackupRestore(file){
 if(!file)return;if(!confirm('Restaurar este backup substituirá os dados atuais do Kumo. Deseja continuar?'))return;
 const btn=$('backupImport');btn.disabled=true;
 try{
  if(!window.JSZip)throw new Error('Biblioteca ZIP indisponível');
  const zip=await JSZip.loadAsync(file), mf=zip.file('kumo-backup.json');if(!mf)throw new Error('Backup Kumo não encontrado.');
  const m=JSON.parse(await mf.async('text'));if(m.format!=='kumo-backup'||m.version!==1||!m.stores)throw new Error('Formato de backup não reconhecido.');
  const prepared={};
  for(const name of ['books','pages','pdfs']){
   prepared[name]=[];
   for(const row of (m.stores[name]||[])){
    let value=row.value;
    if(row.blob){const f=zip.file(row.path);if(!f)throw new Error('Página ausente no backup.');value=await f.async('blob');if(row.type)value=value.slice(0,value.size,row.type);}
    prepared[name].push({key:row.key,value});
   }
  }
  const d=await db();
  await new Promise((resolve,reject)=>{
   const tx=d.transaction(['books','pages','pdfs'],'readwrite');
   for(const name of ['books','pages','pdfs']){const os=tx.objectStore(name);os.clear();for(const row of prepared[name]){if(name==='books')os.put(row.value);else os.put(row.value,row.key)}}
   tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('Restauração cancelada'));
  });
  for(let i=localStorage.length-1;i>=0;i--){const k=localStorage.key(i);if(k&&k.startsWith('kumo:'))localStorage.removeItem(k)}
  for(const [k,v] of Object.entries(m.localStorage||{})){if(k.startsWith('kumo:')&&typeof v==='string')localStorage.setItem(k,v)}
  toast('Backup restaurado. Reabrindo Kumo…',2500);setTimeout(()=>location.reload(),700);
 }catch(e){console.error(e);toast('Falha ao restaurar: '+(e.message||'arquivo inválido'),5000)}finally{btn.disabled=false}
}
const IMGRE=/\.(jpe?g|png|webp|gif|avif|bmp)$/i,EXT={jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',gif:'image/gif',avif:'image/avif',bmp:'image/bmp'};
const typeOf=n=>EXT[(n.split('.').pop()||'').toLowerCase()]||'image/jpeg';
const newId=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const meta=b=>({id:b.id,name:b.name,kind:b.kind,n:b.n,page:b.page,rtl:!!b.rtl,t:b.t,coverUrl:b.coverUrl||null,fav:!!b.fav,col:b.col||'',added:b.added||b.t,fmt:b.fmt||''});
const hydrate=b=>{b.files=Array.from({length:b.n},()=>({}));return b};
let metaT=0;
function flushMeta(){clearTimeout(metaT);metaT=0;if(S.book)idb(['books'],'readwrite',t=>t.objectStore('books').put(meta(S.book))).catch(console.error)}
function saveMetaSoon(){clearTimeout(metaT);metaT=setTimeout(flushMeta,400)}
function saveBm(){try{localStorage.setItem('kumo:bm',JSON.stringify([...S.bookmarks]))}catch{}}
const urls=new Map(),decodedPages=new Map(),preloadJobs=new Map();
async function pageBlobUrl(b,i){const k=b.id+':'+i;let u=urls.get(k);if(u)return u;const bl=await idb(['pages'],'readonly',t=>t.objectStore('pages').get(k));if(!bl)throw new Error('Página ausente');u=urls.get(k)||URL.createObjectURL(bl);urls.set(k,u);return u}
async function preloadPage(b,i){
 if(i<0||i>=b.n)return;
 const key=b.id+':'+i;if(decodedPages.has(key))return decodedPages.get(key);if(preloadJobs.has(key))return preloadJobs.get(key);
 const job=(async()=>{const u=await pageBlobUrl(b,i);const im=new Image();im.decoding='async';im.src=u;
 try{if(im.decode)await im.decode();else await new Promise((ok,no)=>{im.onload=ok;im.onerror=no})}catch(e){throw e}
 decodedPages.set(key,im);return im})().finally(()=>preloadJobs.delete(key));preloadJobs.set(key,job);return job
}
async function pageUrl(b,i){const u=await pageBlobUrl(b,i);
 for(const [k,v] of urls){const j=k.lastIndexOf(':');if(k.slice(0,j)!==b.id||Math.abs(+k.slice(j+1)-i)>4){URL.revokeObjectURL(v);urls.delete(k);decodedPages.delete(k)}}
 // Decode both neighboring pages in the background so the next tap usually animates immediately.
 for(const d of [1,-1]){const n=i+d;if(n>=0&&n<b.n)preloadPage(b,n).catch(()=>{})}
 return u}
async function makeImgCover(blob){const bmp=await createImageBitmap(blob);const sc=Math.min(1,480/Math.max(bmp.width,bmp.height));const c=document.createElement('canvas');c.width=Math.max(1,Math.round(bmp.width*sc));c.height=Math.max(1,Math.round(bmp.height*sc));c.getContext('2d').drawImage(bmp,0,0,c.width,c.height);if(bmp.close)bmp.close();return c.toDataURL('image/jpeg',.85)}
async function addBook(name,kind,blobs,extra={}){
 const n=kind==='pdf'?extra.n:blobs.length;
 if(!n){toast('Nenhuma imagem compatível encontrada.');return}
 const b={id:newId(),name,kind,n,page:0,rtl:kind==='pdf'?false:S.rtl,t:Date.now(),added:Date.now(),fav:false,col:'',fmt:extra.fmt||(kind==='pdf'?'PDF':'IMG'),coverUrl:extra.cover||null};
 if(kind!=='pdf'){try{b.coverUrl=await makeImgCover(blobs[0])}catch(e){console.warn(e)}}
 try{await idb(['books','pages','pdfs'],'readwrite',t=>{const p=t.objectStore('pages');if(blobs)blobs.forEach((bl,i)=>p.put(bl,b.id+':'+i));if(extra.pdfBlob)t.objectStore('pdfs').put(extra.pdfBlob,b.id);t.objectStore('books').put(meta(b))})}
 catch(e){console.error(e);toast('Não foi possível salvar no aparelho (falta de espaço?).');return}
 hydrate(b);if(extra.pdfDoc)b.pdfDoc=extra.pdfDoc;
 S.books.unshift(b);renderLibrary();await openBook(b);toast('Capítulo importado.')}
async function deleteBook(b){
 try{await idb(['books','pages','pdfs'],'readwrite',t=>{t.objectStore('books').delete(b.id);t.objectStore('pdfs').delete(b.id);const p=t.objectStore('pages');for(let i=0;i<b.n;i++)p.delete(b.id+':'+i)})}
 catch(e){console.error(e);toast('Não foi possível excluir.');return}
 for(const [k,u] of urls)if(k.startsWith(b.id+':')){URL.revokeObjectURL(u);urls.delete(k)}
 if(S.book===b)S.book=null;
 for(const k of [...S.bookmarks])if(k.startsWith(b.id+':'))S.bookmarks.delete(k);
 saveBm();S.books=S.books.filter(x=>x!==b);renderLibrary();toast('Título excluído.')}
S.lib={q:'',sort:'recent',view:'grid',filter:'all'};
try{const v=JSON.parse(localStorage.getItem('kumo:lib')||'null');if(v){if(['recent','added','title','progress'].includes(v.sort))S.lib.sort=v.sort;if(v.view==='list')S.lib.view='list'}}catch{}
function saveLib(){try{localStorage.setItem('kumo:lib',JSON.stringify({sort:S.lib.sort,view:S.lib.view}))}catch{}}
const norm=t=>(t||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const isDone=b=>b.n>1&&b.page>=b.n-1;
const stOf=b=>isDone(b)?'done':b.page>0?'reading':'new';
const pctOf=b=>b.n>1?Math.round(b.page/(b.n-1)*100):0;
const putMeta=b=>idb(['books'],'readwrite',t=>t.objectStore('books').put(meta(b))).catch(console.error);
const ICON_GRID='<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><rect x="13" y="13" width="7" height="7" rx="2"/></svg>';
const ICON_LIST='<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.5" cy="6" r="1"/><circle cx="4.5" cy="12" r="1"/><circle cx="4.5" cy="18" r="1"/></svg>';
function paintView(){$('viewToggle').innerHTML=S.lib.view==='grid'?ICON_LIST:ICON_GRID}
function visibleBooks(){
 const L=S.lib,q=norm(L.q);
 const a=S.books.filter(b=>{
  if(q&&!norm(b.name).includes(q)&&!norm(b.col).includes(q))return false;
  const f=L.filter;
  if(f==='fav')return !!b.fav;
  if(f==='reading'||f==='new'||f==='done')return stOf(b)===f;
  if(f.startsWith('col:'))return (b.col||'')===f.slice(4);
  return true});
 const cmp={recent:(x,y)=>(y.t||0)-(x.t||0),added:(x,y)=>(y.added||y.t||0)-(x.added||x.t||0),title:sort,progress:(x,y)=>pctOf(y)-pctOf(x)}[L.sort]||sort;
 return a.sort(cmp)}
function subLine(b){const st=stOf(b);return (b.col?b.col+' · ':'')+(st==='new'?b.n+(b.n===1?' página':' páginas'):st==='done'?'Concluído · '+b.n+' págs':'Pág. '+(b.page+1)+' de '+b.n+' · '+pctOf(b)+'%')}
function renderChips(){
 const box=$('chips'),sl=box.scrollLeft;box.innerHTML='';
 const cnt=f=>S.books.filter(b=>f==='all'||(f==='fav'?b.fav:stOf(b)===f)).length;
 const defs=[['all','Todos'],['reading','Lendo'],['new','Não lidos'],['done','Concluídos'],['fav','★ Favoritos']];
 [...new Set(S.books.map(b=>b.col).filter(Boolean))].sort((a,b)=>a.localeCompare(b,undefined,{sensitivity:'base'})).forEach(c=>defs.push(['col:'+c,'▤ '+c]));
 if(!defs.some(d=>d[0]===S.lib.filter))S.lib.filter='all';
 defs.forEach(([k,l])=>{const b=document.createElement('button');b.className='chip'+(S.lib.filter===k?' on':'');const n=k.startsWith('col:')?S.books.filter(x=>x.col===k.slice(4)).length:cnt(k);b.innerHTML='<span></span><em>'+n+'</em>';b.firstChild.textContent=l;b.onclick=()=>{S.lib.filter=k;renderLibrary(true)};box.append(b)});
 box.scrollLeft=sl}
function renderResume(){
 const r=$('resume'),b=S.books.find(x=>stOf(x)==='reading');
 r.innerHTML='';
 if(!b){r.classList.add('hidden');return}
 r.classList.remove('hidden');r.style.setProperty('--cv',b.coverUrl?'url("'+b.coverUrl+'")':'none');
 const c=document.createElement('div');c.className='rc-cover';
 if(b.coverUrl){const im=new Image();im.alt='';im.src=b.coverUrl;c.append(im)}else{const sp=document.createElement('span');sp.textContent='雲';c.append(sp)}
 const i=document.createElement('div');i.className='rc-info';
 i.innerHTML='<span class="eyebrow">Continue de onde parou</span><b></b><small></small><div class="bar"><i></i></div>';
 i.querySelector('b').textContent=b.name;i.querySelector('small').textContent='Página '+(b.page+1)+' de '+b.n+' · '+pctOf(b)+'%';i.querySelector('.bar i').style.setProperty('--p',(pctOf(b)/100).toFixed(3));
 const btn=document.createElement('button');btn.className='primary';btn.textContent='▶ Continuar';i.append(btn);
 r.append(c,i);r.onclick=()=>openBook(b)}
function renderRail(){
 const first=S.books.find(x=>stOf(x)==='reading'),box=$('continue'),list=S.books.filter(b=>stOf(b)==='reading'&&b!==first).slice(0,10);
 box.innerHTML='';$('continueBlock').classList.toggle('hidden',!list.length);
 list.forEach((b,i)=>box.append(card(b,i)))}
function toggleFav(b){b.fav=!b.fav;putMeta(b);if(navigator.vibrate)try{navigator.vibrate(10)}catch{}}
function card(b,i=0){
 const el=document.createElement('article');el.className='book st-'+stOf(b);el.style.setProperty('--i',Math.min(i,14));
 const cv=document.createElement('div');cv.className='cover';
 if(b.coverUrl){const im=new Image();im.alt='Capa de '+b.name;im.decoding='async';im.draggable=false;im.onload=()=>im.classList.add('ld');im.src=b.coverUrl;cv.append(im)}else{const sp=document.createElement('span');sp.className='ph';sp.textContent='雲';cv.append(sp)}
 const fmt=b.fmt||(b.kind==='pdf'?'PDF':'');
 if(fmt){const f=document.createElement('span');f.className='badge fmt';f.textContent=fmt;cv.append(f)}
 const st=stOf(b);
 if(st!=='reading'){const f=document.createElement('span');f.className='badge st'+(st==='done'?' done':'');f.textContent=st==='done'?'✓ LIDO':'NOVO';cv.append(f)}
 const fav=document.createElement('button');fav.className='fav'+(b.fav?' on':'');fav.textContent=b.fav?'★':'☆';fav.setAttribute('aria-label','Favoritar '+b.name);
 fav.onclick=ev=>{ev.stopPropagation();toggleFav(b);fav.classList.toggle('on',b.fav);fav.textContent=b.fav?'★':'☆';if(S.lib.filter==='fav')renderLibrary(true);else renderChips()};
 const more=document.createElement('button');more.className='more';more.textContent='⋯';more.setAttribute('aria-label','Mais opções de '+b.name);
 more.onclick=ev=>{ev.stopPropagation();openSheet(b)};
 cv.append(fav,more);
 const info=document.createElement('div');info.className='info';info.innerHTML='<b></b><small></small><div class="bar"><i></i></div>';
 info.querySelector('b').textContent=b.name;info.querySelector('small').textContent=subLine(b);info.querySelector('.bar i').style.setProperty('--p',(pctOf(b)/100).toFixed(3));
 el.append(cv,info);
 let t=0;el.onclick=()=>{if(el._lp){el._lp=false;return}openBook(b)};
 el.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;clearTimeout(t);t=setTimeout(()=>{el._lp=true;if(navigator.vibrate)try{navigator.vibrate(14)}catch{};openSheet(b)},500)});
 ['pointerup','pointerleave','pointercancel'].forEach(ev=>el.addEventListener(ev,()=>clearTimeout(t)));
 return el}
function renderLibrary(quick){
 S.libDirty=false;
 const n=S.books.length,has=n>0;
 $('countBooks').textContent=n+' '+(n===1?'título':'títulos');
 $('hero').classList.toggle('hidden',has);
 ['libTools','chips','libHead'].forEach(id=>$(id).classList.toggle('hidden',!has));
 renderResume();renderRail();if(has)renderChips();
 const list=$('books');list.innerHTML='';
 if(!has){list.className='';return}
 const v=visibleBooks();
 if(!v.length){list.className='';const e=document.createElement('div');e.className='empty';e.textContent=S.lib.q?'Nenhum título encontrado para “'+S.lib.q+'”.':'Nada aqui ainda.';list.append(e);return}
 list.className='books'+(S.lib.view==='list'?' list':'')+(quick?' quick':'');
 v.forEach((b,i)=>list.append(card(b,i)))}
/* folha de detalhes do título */
let shBook=null;
function metaLine(b){const st=stOf(b);return (b.fmt||(b.kind==='pdf'?'PDF':'Imagens'))+' · '+b.n+' págs · '+(st==='done'?'Concluído':st==='reading'?'Lendo '+pctOf(b)+'%':'Não lido')}
function paintSheet(){const b=shBook;if(!b)return;
 $('shTitle').textContent=b.name;$('shMeta').textContent=metaLine(b);
 const mc=$('shCover');mc.innerHTML='';if(b.coverUrl){const im=new Image();im.alt='';im.src=b.coverUrl;mc.append(im)}else mc.textContent='雲';
 $('shFav').textContent=b.fav?'★ Favorito':'☆ Favoritar';
 $('shRead').textContent=isDone(b)?'↺ Marcar como não lido':'✓ Marcar como lido';
 $('shRead').classList.toggle('hidden',b.n<2);
 $('shCoverBtn').classList.toggle('hidden',b.kind==='pdf')}
function renderColChips(){const box=$('shCols');box.innerHTML='';const cols=[...new Set(S.books.map(b=>b.col).filter(Boolean))].sort();cols.forEach(c=>{const x=document.createElement('button');x.className='chip sm';x.textContent=c;x.onclick=()=>{$('shCol').value=c};box.append(x)});box.classList.toggle('hidden',!cols.length)}
function openSheet(b){shBook=b;$('shName').value=b.name;$('shCol').value=b.col||'';paintSheet();renderColChips();
 const d=$('shDel');d.classList.remove('arm');d.textContent='🗑 Excluir título';
 const r=$('sheetRoot');r.classList.remove('hidden');requestAnimationFrame(()=>requestAnimationFrame(()=>r.classList.add('open')))}
function hideSheet(){const r=$('sheetRoot');r.classList.remove('open');setTimeout(()=>{if(!shBook)r.classList.add('hidden')},420)}
function applySheetFields(){const b=shBook;if(!b)return;
 const nm=$('shName').value.trim().slice(0,120),col=$('shCol').value.trim().slice(0,30);let ch=false;
 if(nm&&nm!==b.name){b.name=nm;ch=true;if(S.book===b)$('bookTitle').textContent=nm}
 if(col!==(b.col||'')){b.col=col;ch=true}
 if(ch){putMeta(b);renderLibrary(true)}}
function closeSheet(){if(!shBook){hideSheet();return}applySheetFields();shBook=null;hideSheet()}
async function setCoverFromPage(b){
 try{const bl=await idb(['pages'],'readonly',t=>t.objectStore('pages').get(b.id+':'+b.page));if(!bl)throw new Error('x');b.coverUrl=await makeImgCover(bl);await putMeta(b);paintSheet();renderLibrary(true);toast('Capa atualizada.')}
 catch(e){console.error(e);toast('Não foi possível trocar a capa.')}}
function bindLibUI(){
 const q=$('q');q.addEventListener('input',()=>{S.lib.q=q.value;$('qclear').classList.toggle('hidden',!q.value);renderLibrary(true)});
 $('qclear').onclick=()=>{q.value='';S.lib.q='';$('qclear').classList.add('hidden');renderLibrary(true);q.focus()};
 const so=$('sort');so.value=S.lib.sort;so.onchange=()=>{S.lib.sort=so.value;saveLib();renderLibrary(true)};
 $('viewToggle').onclick=()=>{S.lib.view=S.lib.view==='grid'?'list':'grid';saveLib();paintView();renderLibrary(true)};
 paintView();
 $('sheetBg').onclick=closeSheet;$('shClose').onclick=closeSheet;
 $('shFav').onclick=()=>{const b=shBook;if(!b)return;toggleFav(b);paintSheet();renderLibrary(true)};
 $('shRead').onclick=()=>{const b=shBook;if(!b)return;b.page=isDone(b)?0:b.n-1;putMeta(b);paintSheet();renderLibrary(true)};
 $('shCoverBtn').onclick=()=>{if(shBook)setCoverFromPage(shBook)};
 $('shDel').onclick=()=>{const b=shBook,d=$('shDel');if(!b)return;
  if(!d.classList.contains('arm')){d.classList.add('arm');d.textContent='Toque de novo para excluir';clearTimeout(d._t);d._t=setTimeout(()=>{d.classList.remove('arm');d.textContent='🗑 Excluir título'},3000);return}
  shBook=null;hideSheet();deleteBook(b)}}
function setupPdf(){pdfjsLib.GlobalWorkerOptions.workerSrc=new URL('lib/pdf.worker.min.js',location.href).href}
async function openBook(b){
 try{if(b.kind==='pdf'&&!b.pdfDoc){if(!window.pdfjsLib)throw new Error('pdf');setupPdf();const bl=await idb(['pdfs'],'readonly',t=>t.objectStore('pdfs').get(b.id));b.pdfDoc=await pdfjsLib.getDocument({data:await bl.arrayBuffer()}).promise}}
 catch(e){console.error(e);toast('Não foi possível abrir este PDF.');return}
 b.t=Date.now();S.books=[b,...S.books.filter(x=>x!==b)];
 S.book=b;S.page=Math.min(b.page,b.files.length-1);S.mode=$('mode').value;S.zoom=1;S.rtl=!!b.rtl;$('rtl').checked=S.rtl;S.pdfRender++;show('readerScreen');$('bookTitle').textContent=b.name;theme();renderPage(false)}
function theme(){let color=S.theme==='black'?'#000':S.theme==='light'?'#f2efe8':S.theme==='sepia'?'#e8d9bb':'#08080b';$('reader').style.background=color;$('stage').style.background=color;document.documentElement.style.setProperty('--accent',S.theme==='sepia'?'#916b42':'#b9a2ff')}
async function renderPage(animate=true){
if(!S.book)return;
S.page=Math.max(0,Math.min(S.page,S.book.files.length-1));S.book.page=S.page;saveMetaSoon();
const stage=$('stage');
const token=++S.pdfRender;
let oldWrap=null;
if(animate&&S.mode!=='vertical'&&S.transition!=='none'){
 oldWrap=[...stage.querySelectorAll('.page-wrap')].filter(w=>w.firstChild).pop()||null;
}
S.zoom=Math.max(1,Math.min(4,S.zoom));
const item=S.book.files[S.page];
/* Build the destination page OFF-DOM. Never expose an empty image/canvas
   in the visible stage while its source is loading or rendering. */
const wrap=document.createElement('div');wrap.className='page-wrap';
let pageEl;
try{
 if(S.book.kind==='pdf'){
  const page=await S.book.pdfDoc.getPage(S.page+1);if(token!==S.pdfRender)return;
  const base=page.getViewport({scale:1,rotation:page.rotate});
  const sw=Math.max(240,stage.clientWidth||window.innerWidth),sh=Math.max(240,stage.clientHeight||window.innerHeight);
  let scale=Math.min(2.5,sw/base.width);
  if(S.mode==='height')scale=Math.min(2.5,sh/base.height);
  if(S.mode==='vertical')scale=Math.min(2.5,sw/base.width);
  const viewport=page.getViewport({scale,rotation:page.rotate});
  const baseWidth=viewport.width,baseHeight=viewport.height;
  S.basePageWidth=baseWidth;S.basePageHeight=baseHeight;
  const canvas=document.createElement('canvas');canvas.setAttribute('aria-label',S.book.name+', página '+(S.page+1));
  const dpr=Math.min(window.devicePixelRatio||1,2);canvas.width=Math.floor(viewport.width*dpr);canvas.height=Math.floor(viewport.height*dpr);
  canvas.style.width=viewport.width+'px';canvas.style.height=viewport.height+'px';canvas.style.filter='brightness('+(S.brightness/100)+')';
  const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);
  wrap.append(canvas);pageEl=canvas;
  wrap.style.width=viewport.width+'px';wrap.style.height=viewport.height+'px';
  await page.render({canvasContext:ctx,viewport}).promise;if(token!==S.pdfRender)return;
 }else{
  const pageKey=S.book.id+':'+S.page;let cached=decodedPages.get(pageKey);
  if(!cached)cached=await preloadPage(S.book,S.page);
  if(token!==S.pdfRender)return;
  const img=cached.cloneNode(false);img.src=cached.src;img.alt=S.book.name+', página '+(S.page+1);img.draggable=false;img.style.filter='brightness('+(S.brightness/100)+')';
  if(img.decode)await img.decode().catch(()=>{});else if(!img.complete)await new Promise(ok=>{img.onload=ok;img.onerror=ok});
  if(token!==S.pdfRender)return;
  let w=img.naturalWidth||800,h=img.naturalHeight||1200;
  const sw=Math.max(240,stage.clientWidth||window.innerWidth),sh=Math.max(240,stage.clientHeight||window.innerHeight);
  let scale=Math.min(1,sw/w,sh/h);
  if(S.mode==='width'||S.mode==='vertical')scale=Math.min(2.5,sw/w);
  if(S.mode==='height')scale=Math.min(2.5,sh/h);
  S.basePageWidth=Math.max(1,w*scale);S.basePageHeight=Math.max(1,h*scale);
  img.style.width=S.basePageWidth+'px';img.style.height=S.basePageHeight+'px';
  wrap.style.width=S.basePageWidth+'px';wrap.style.height=S.basePageHeight+'px';wrap.append(img);pageEl=img;
 }
 if(token!==S.pdfRender)return;
 pageEl.style.transform='scale('+S.zoom+')';
 wrap.style.width=(S.basePageWidth*S.zoom)+'px';wrap.style.height=(S.basePageHeight*S.zoom)+'px';
 /* Only now replace/animate visible content: destination is fully ready. */
 stage.className='stage'+(S.mode==='vertical'?' vertical':S.mode==='width'?' width':S.mode==='height'?' height':'');
 if(S.zoom>1)stage.classList.add('zoomed');
 if(oldWrap&&oldWrap.isConnected){
  const sr=stage.getBoundingClientRect(),r=oldWrap.getBoundingClientRect();
  oldWrap.style.position='absolute';oldWrap.style.left=(r.left-sr.left+stage.scrollLeft)+'px';oldWrap.style.top=(r.top-sr.top+stage.scrollTop)+'px';
  oldWrap.style.margin='0';oldWrap.style.pointerEvents='none';
  stage.replaceChildren(oldWrap,wrap);
  slideIn(stage,oldWrap,wrap);
 }else{
  stage.replaceChildren(wrap);
  stage.style.overflow='';
 }
 $('pageSub').textContent='Página '+(S.page+1)+' de '+S.book.files.length;$('pageCount').textContent=(S.page+1)+' / '+S.book.files.length;$('slider').max=S.book.files.length;$('slider').value=S.page+1;let key=S.book.id+':'+S.page;$('favorite').textContent=S.bookmarks.has(key)?'★':'☆';$('favStatus').textContent=S.bookmarks.has(key)?'★ Página favorita':'Sem favorito';$('modeButton').textContent=S.mode==='vertical'?'☰ Vertical':S.mode==='width'?'↔ Largura':S.mode==='height'?'↕ Altura':'▤ Página';S.libDirty=true;
}catch(err){console.error(err);if(token===S.pdfRender)toast('Não foi possível renderizar esta página.');}
}

function applyZoom(z,clientX,clientY){
 const stage=$('stage'),wrap=stage.querySelector('.page-wrap'),el=wrap?.querySelector('img,canvas');if(!wrap||!el)return;
 const old=S.zoom,n=Math.max(1,Math.min(4,z));if(Math.abs(n-old)<.001)return;
 const sr=stage.getBoundingClientRect(),wr=wrap.getBoundingClientRect();
 const ax=clientX==null?stage.clientWidth/2:clientX-sr.left,ay=clientY==null?stage.clientHeight/2:clientY-sr.top;
 const left=wrap.offsetLeft,top=wrap.offsetTop;
 const localX=(ax+stage.scrollLeft-left)/old,localY=(ay+stage.scrollTop-top)/old;
 S.zoom=n;el.style.transform='scale('+n+')';wrap.style.width=(S.basePageWidth*n)+'px';wrap.style.height=(S.basePageHeight*n)+'px';
 stage.classList.toggle('zoomed',n>1);
 stage.scrollLeft=Math.max(0,left+localX*n-ax);stage.scrollTop=Math.max(0,top+localY*n-ay);
 if(n===1){stage.scrollLeft=0;stage.scrollTop=0}
}
function setZoom(z){applyZoom(z);toast('Zoom: '+Math.round(S.zoom*100)+'%')}
function toggleFullscreen(){if(window.KumoNative){window.KumoNative.setFullscreen(!window.KumoNative.isFullscreen());return}let el=$('reader');if(!document.fullscreenElement){let req=el.requestFullscreen||el.webkitRequestFullscreen;if(req){Promise.resolve(req.call(el)).catch(()=>toast('Tela cheia não disponível neste navegador.'))}else toast('Tela cheia não suportada neste navegador.')}else{let exit=document.exitFullscreen||document.webkitExitFullscreen;if(exit)exit.call(document)}}
function slideIn(stage,oldWrap,wrap){
 const v=S.anim||1,W=stage.clientWidth||innerWidth,fade=S.transition==='fade',o={duration:fade?220:260,easing:'cubic-bezier(.2,.8,.2,1)',fill:'both'};
 stage.style.overflow='hidden';
 const a=oldWrap.animate(fade?[{opacity:1},{opacity:0}]:[{transform:'translateX(0)'},{transform:'translateX('+(-v*W)+'px)'}],o);
 const b=wrap.animate(fade?[{opacity:0},{opacity:1}]:[{transform:'translateX('+(v*W)+'px)'},{transform:'translateX(0)'}],o);
 Promise.allSettled([a.finished,b.finished]).then(()=>{oldWrap.remove();stage.style.overflow='';a.cancel();b.cancel()})}
function turn(d){if(!S.book)return;let n=S.page+((S.book?S.book.rtl:S.rtl)?-d:d);if(n<0||n>=S.book.files.length){toast(n<0?'Primeira página.':'Fim do capítulo.');return}S.page=n;S.anim=d;renderPage(true)}
function openImportChoice(){toast('Escolha imagens, CBZ/ZIP ou PDF na biblioteca.')}
async function importImages(files){
 const list=[...files].filter(f=>f.type.startsWith('image/')||IMGRE.test(f.name)).sort(sort);
 if(!list.length){toast('Selecione arquivos de imagem válidos.');return}
 toast('Importando…');
 await addBook(list.length===1?list[0].name.replace(/\.[^.]+$/,''):'Capítulo importado','images',list.map(f=>f.slice(0,f.size,f.type||typeOf(f.name))),{fmt:'IMG'})}
async function sniff(f){const h=new Uint8Array(await f.slice(0,5).arrayBuffer());if(h[0]===0x25&&h[1]===0x50&&h[2]===0x44&&h[3]===0x46)return'pdf';if(h[0]===0x50&&h[1]===0x4B)return'zip';if(h[0]===0x52&&h[1]===0x61&&h[2]===0x72)return'rar';if(h[0]===0x37&&h[1]===0x7A)return'rar';return''}
async function importAny(files){
 const list=[...files];if(!list.length)return;
 const isImg=f=>f.type.startsWith('image/')||IMGRE.test(f.name);
 if(list.every(isImg))return importImages(list);
 const f=list.find(x=>!isImg(x));let k='';
 try{k=await sniff(f)}catch{}
 if(!k){const n=f.name.toLowerCase();k=/\.pdf$/.test(n)?'pdf':/\.(cbz|zip)$/.test(n)?'zip':''}
 if(k==='pdf')return importPdf(f);
 if(k==='zip')return importZip(f);
 toast(k==='rar'?'CBR/RAR e CB7 ainda não são suportados. Converta para CBZ.':'Formato não suportado. Use imagens, CBZ/ZIP ou PDF.',4200)}
async function importZip(f){if(!f)return;if(!window.JSZip){toast('Não foi possível carregar o leitor ZIP.');return}try{toast('Abrindo arquivo…');let z=await JSZip.loadAsync(f),entries=Object.values(z.files).filter(x=>!x.dir&&IMGRE.test(x.name)&&!/(^|\/)(__MACOSX\/|\.)/.test(x.name)).sort(sort),blobs=[];for(let x of entries){let bl=await x.async('blob');blobs.push(bl.slice(0,bl.size,typeOf(x.name)))}await addBook(f.name.replace(/\.(cbz|zip)$/i,''),'images',blobs,{fmt:'CBZ'})}catch(e){console.error(e);toast('Arquivo inválido ou corrompido.')} }
async function makePdfCover(doc){
 const page=await doc.getPage(1), viewport=page.getViewport({scale:1});
 const scale=Math.min(1,360/Math.max(viewport.width,viewport.height));
 const thumb=page.getViewport({scale});
 const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(thumb.width));canvas.height=Math.max(1,Math.round(thumb.height));
 const ctx=canvas.getContext('2d',{alpha:false});
 await page.render({canvasContext:ctx,viewport:thumb,background:'#fff'}).promise;
 return canvas.toDataURL('image/jpeg',.82);
}
async function importPdf(f){if(!f)return;if(!window.pdfjsLib){toast('O motor PDF não carregou.');return}try{toast('Abrindo PDF…');setupPdf();const pdfBlob=f.slice(0,f.size,'application/pdf');let doc=await pdfjsLib.getDocument({data:await pdfBlob.arrayBuffer()}).promise;let cover=await makePdfCover(doc);await addBook(f.name.replace(/\.pdf$/i,''),'pdf',null,{n:doc.numPages,cover,pdfBlob,pdfDoc:doc});toast('PDF importado: '+doc.numPages+' páginas.')}catch(err){console.error(err);toast('Não foi possível abrir este PDF.')} }

$('importTop').onclick=$('importHero').onclick=()=>$('anyFile').click();$('importImages').onclick=()=>$('imageFiles').click();$('importZip').onclick=()=>$('zipFile').click();$('importPdf').onclick=()=>$('pdfFile').click();$('imageFiles').onchange=e=>{importImages(e.target.files);e.target.value=''};$('zipFile').onchange=e=>{importZip(e.target.files[0]);e.target.value=''};$('pdfFile').onchange=e=>{importPdf(e.target.files[0]);e.target.value=''};$('anyFile').onchange=e=>{importAny(e.target.files);e.target.value=''};
$('settingsTop').onclick=$('readerSettings').onclick=()=>show('settings');$('rtl').onchange=e=>{S.rtl=e.target.checked;if(S.book)S.book.rtl=S.rtl};$('backHome').onclick=()=>show(S.settingsReturn||'home');document.querySelectorAll('.nav button').forEach(b=>b.onclick=()=>show(b.dataset.target));$('close').onclick=()=>show('home');$('prev').onclick=()=>turn(-1);$('next').onclick=()=>turn(1);$('slider').oninput=e=>{if(S.book){S.page=+e.target.value-1;renderPage(false)}};$('favorite').onclick=()=>{if(!S.book)return;let k=S.book.id+':'+S.page;S.bookmarks.has(k)?S.bookmarks.delete(k):S.bookmarks.add(k);saveBm();renderPage(false)};
$('mode').onchange=()=>{S.mode=$('mode').value;if(S.book){S.zoom=1;renderPage(false)}};$('zoomIn').onclick=()=>setZoom(S.zoom+.25);$('zoomOut').onclick=()=>setZoom(S.zoom-.25);$('fullscreen').onclick=toggleFullscreen;document.addEventListener('fullscreenchange',()=>{$('fullscreen').textContent=document.fullscreenElement?'⤢':'⛶'});$('modeButton').onclick=()=>{let a=['paged','vertical','width','height'];S.mode=a[(a.indexOf(S.mode)+1)%a.length];$('mode').value=S.mode;saveSet();renderPage(false)};$('quickBright').onclick=()=>show('settings');$('brightness').oninput=e=>{S.brightness=+e.target.value;$('brightLabel').textContent=S.brightness+'%';let img=$('stage').querySelector('img,canvas');if(img)img.style.filter='brightness('+(S.brightness/100)+')';$('brightnessOverlay').style.opacity=String(Math.max(0,(100-S.brightness)/150))};$('theme').onchange=e=>{S.theme=e.target.value;theme()};$('transition').onchange=e=>S.transition=e.target.value;$('mode').onchange=e=>{S.mode=e.target.value;if(S.book)renderPage(false)};$('rtl').onchange=e=>{S.rtl=e.target.checked;if(S.book)S.book.rtl=S.rtl};
$('keepAwake').onchange=async e=>{if(window.KumoNative){window.KumoNative.setKeepAwake(e.target.checked);return}try{if(e.target.checked&&navigator.wakeLock)S.wake=await navigator.wakeLock.request('screen');else if(S.wake){await S.wake.release();S.wake=null}if(e.target.checked&&!navigator.wakeLock)toast('Não suportado neste navegador.')}catch{toast('Não foi possível manter a tela ligada.')}};
$('stage').onclick=e=>{if(!S.book||S.zoom>1.01||Date.now()-(S.tapAt||0)<600)return;let r=$('stage').getBoundingClientRect(),x=e.clientX-r.left;if(!$('tapZones').checked){$('reader').classList.toggle('hide-ui');return}if(x<r.width*.27)turn(-1);else if(x>r.width*.73)turn(1);else $('reader').classList.toggle('hide-ui')};
$('stage').addEventListener('wheel',e=>{if(e.ctrlKey||e.metaKey){e.preventDefault();applyZoom(S.zoom+(e.deltaY<0?.15:-.15),e.clientX,e.clientY)}},{passive:false});
const stageEl=$('stage');
stageEl.addEventListener('pointerdown',e=>{
 if(e.pointerType==='mouse'&&e.button!==0)return;
 stageEl.setPointerCapture?.(e.pointerId);S.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(S.pointers.size===1){S.drag={x:e.clientX,y:e.clientY,scrollLeft:stageEl.scrollLeft,scrollTop:stageEl.scrollTop,moved:false};}
 if(S.pointers.size===2){const a=[...S.pointers.values()];S.pinch={distance:Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y),zoom:S.zoom,midX:(a[0].x+a[1].x)/2,midY:(a[0].y+a[1].y)/2};S.drag=null;}
});
stageEl.addEventListener('pointermove',e=>{
 if(!S.pointers.has(e.pointerId))return;S.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(S.pointers.size>=2&&S.pinch){const a=[...S.pointers.values()],dist=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y),midX=(a[0].x+a[1].x)/2,midY=(a[0].y+a[1].y)/2;applyZoom(S.pinch.zoom*dist/Math.max(1,S.pinch.distance),midX,midY);S.pinch.midX=midX;S.pinch.midY=midY;e.preventDefault();return}
 if(S.drag&&S.zoom>1){const dx=e.clientX-S.drag.x,dy=e.clientY-S.drag.y;if(Math.abs(dx)+Math.abs(dy)>3)S.drag.moved=true;stageEl.scrollLeft=S.drag.scrollLeft-dx;stageEl.scrollTop=S.drag.scrollTop-dy;e.preventDefault();}
});
function endPointer(e){const wasPinch=!!S.pinch;S.pointers.delete(e.pointerId);if(S.pointers.size<2)S.pinch=null;if(S.pointers.size===0){const drag=S.drag;S.drag=null;if(drag)S.tapAt=Date.now();if(!wasPinch&&drag&&S.zoom<=1.01&&!drag.moved&&S.book){const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.abs(dx)>55&&Math.abs(dx)>Math.abs(dy)*1.2)turn(dx<0?1:-1);else if(Math.abs(dx)<12&&Math.abs(dy)<12){const r=stageEl.getBoundingClientRect(),x=e.clientX-r.left;if($('tapZones').checked){if(x<r.width*.27)turn(-1);else if(x>r.width*.73)turn(1);else $('reader').classList.toggle('hide-ui')}else $('reader').classList.toggle('hide-ui')}}}}
stageEl.addEventListener('pointerup',endPointer);stageEl.addEventListener('pointercancel',endPointer);stageEl.addEventListener('lostpointercapture',e=>{S.pointers.delete(e.pointerId);if(!S.pointers.size){S.pinch=null;S.drag=null}});
document.addEventListener('keydown',e=>{if(!$('readerScreen').classList.contains('active'))return;if(e.key==='ArrowRight')turn(1);else if(e.key==='ArrowLeft')turn(-1);else if(e.key===' '){e.preventDefault();turn(1)}else if(e.key==='Escape'){if(document.fullscreenElement)toggleFullscreen();else show('home')}});
function saveSet(){try{localStorage.setItem('kumo:set',JSON.stringify({brightness:+$('brightness').value,theme:$('theme').value,transition:$('transition').value,mode:$('mode').value,tapZones:$('tapZones').checked,keepAwake:$('keepAwake').checked}))}catch{}}
function loadSet(){let v=null;try{v=JSON.parse(localStorage.getItem('kumo:set')||'null')}catch{}if(!v)return;
 const set=(id,val,ev)=>{const el=$(id);if(val==null)return;if(el.type==='checkbox')el.checked=!!val;else el.value=val;el.dispatchEvent(new Event(ev))};
 set('brightness',v.brightness,'input');set('theme',v.theme,'change');set('transition',v.transition,'change');set('mode',v.mode,'change');set('tapZones',v.tapZones,'change');
 if(v.keepAwake&&window.KumoNative)set('keepAwake',true,'change')}
$('settings').addEventListener('change',()=>{saveSet();saveMetaSoon()});$('settings').addEventListener('input',saveSet);
async function init(){
 try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist()}catch{}
 try{JSON.parse(localStorage.getItem('kumo:bm')||'[]').forEach(k=>S.bookmarks.add(k))}catch{}
 try{const rows=await idb(['books'],'readonly',t=>t.objectStore('books').getAll());S.books=rows.sort((a,b)=>(b.t||0)-(a.t||0)).map(hydrate);renderLibrary()}catch(e){console.error(e);toast('Não foi possível ler a biblioteca salva.')}}
window.kumoBack=()=>{if(!$('sheetRoot').classList.contains('hidden')){closeSheet();return true}if($('readerScreen').classList.contains('active')){if(window.KumoNative&&window.KumoNative.isFullscreen()){window.KumoNative.setFullscreen(false);return true}show('home');return true}if($('settings').classList.contains('active')){show(S.settingsReturn||'home');return true}return false};
$('backupExport').addEventListener('click',kumoBackupExport);$('backupImport').addEventListener('click',()=>$('backupFile').click());$('backupFile').addEventListener('change',e=>{const f=e.target.files?.[0];if(f)kumoBackupRestore(f);e.target.value=''});window.kumoSave=flushMeta;window.kumoFsChanged=on=>{$('fullscreen').textContent=on?'⤢':'⛶'};
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')flushMeta()});
document.addEventListener('contextmenu',e=>e.preventDefault());
let rzT,pw=innerWidth,ph=innerHeight;window.addEventListener('resize',()=>{clearTimeout(rzT);rzT=setTimeout(()=>{if(Math.abs(innerWidth-pw)<40&&Math.abs(innerHeight-ph)<40)return;pw=innerWidth;ph=innerHeight;if(S.book&&$('readerScreen').classList.contains('active'))renderPage(false)},250)});
bindLibUI();renderLibrary();loadSet();init();setTimeout(()=>document.body.classList.remove('booting'),1900);
})();
